package com.example.task_1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    TextView showValue;
    int counter = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        showValue = (TextView) findViewById(R.id.counterValue);
    }

    @SuppressLint("SetTextI18n")
    public void countIN (View view) {
        counter++;
        showValue.setText(Integer.toString(counter));
    }

    @SuppressLint("SetTextI18n")
    public void countDE (View v) {
        counter--;
        showValue.setText(Integer.toString(counter));
    }

    public void resetCount (View view) {
        counter = 0;
        showValue.setText(String.valueOf(counter));
    }

    @SuppressLint("ShowToast")
    public void toast (View view) {
        Toast.makeText(MainActivity.this,"The count is counter", Toast.LENGTH_SHORT);
    }


}